package Student_package;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.Scanner;

public class Student_info {
	public static void registerStudent_details() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter rollno : ");
		int rollno = s.nextInt();
		System.out.println("enter name : ");
		String name = s.next();
		System.out.println("enter age : ");
		int age = s.nextInt();
		System.out.println("enter class : ");
		int std_class = s.nextInt();
		System.out.println("enter address : ");
		String address = s.next();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("insert into student values(?,?,?,?,?)");
			ps.setInt(1, rollno);
			ps.setString(2, name);
			ps.setInt(3, age);
			ps.setInt(4, std_class);
			ps.setString(5, address);
			ps.execute();
			System.out.println("executed.............");
		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void updateStudentDetailsByStdId() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student rollno : ");
		int rollno = s.nextInt();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where roll=?");
			ps.setInt(1, rollno);
			ResultSet res = ps.executeQuery();
			if (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
				System.out.println("enter new address : ");
				String address = s.next();
				ps = con.prepareStatement("update student set address=? where roll=?");
				ps.setString(1, address);
				ps.setInt(2, rollno);
				ps.execute();
				System.out.println("Query executed.....");
			} else {
				System.out.println("records not found..........");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void updateStudentDetailsByStdname() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student name : ");
		String name = s.next();
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where name=?");
			ps.setString(1, name);
			ResultSet res = ps.executeQuery();
			if (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
				System.out.println("enter new address : ");
				String address = s.next();
				ps = con.prepareStatement("update student set address=? where name=?");
				ps.setString(1, address);
				ps.setString(2, name);
				ps.execute();
				System.out.println("Query executed.....");
			} else {
				System.out.println("records not found..........");
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void fetchAllDetails() {
		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student");
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void fetchAllDetailsByclass() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student class : ");
		int std_class = s.nextInt();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where std_class=?");
			ps.setInt(1, std_class);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void fetchAllDetailsByname() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student name : ");
		String name = s.next();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where name=?");
			ps.setString(1, name);
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
			}

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void deleteDetailsByrollno() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student rollno : ");
		int roll = s.nextInt();

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("delete from student where roll=?");
			ps.setInt(1, roll);
			ps.execute();
			System.out.println("deleted 1 row ....");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void searchStudentByletter() {
		Scanner s = new Scanner(System.in);
		System.out.println("enter student letter : ");
		String letter = s.next();
		letter = "%" + letter + "%";

		try {
			Class.forName("com.mysql.cj.jdbc.Driver");
			Connection con = DriverManager.getConnection("jdbc:mysql://localhost:3306/student_info", "root", "root");
			PreparedStatement ps = con.prepareStatement("select * from student where name like '" + letter + "'");
			ResultSet res = ps.executeQuery();
			while (res.next()) {
				System.out.println(res.getInt(1) + " " + res.getString(2) + " " + res.getInt(3) + " " + res.getInt(4)
						+ " " + res.getString(5));
			}

			System.out.println("executes 1 row ....");

		} catch (ClassNotFoundException | SQLException e) {
			e.printStackTrace();
		}
	}

	public static void main(String[] args) {
		while (true) {
			System.out.println("---welcome to school database ---");
			Scanner s = new Scanner(System.in);
			System.out.println("enter your choice : ");
			System.out.println("1)Register student details....");
			System.out.println("2)Update Student details by Student rollno....");
			System.out.println("3)Update student details by student name......");
			System.out.println("4)Fetch all student deatils......");
			System.out.println("5)Fetch all student details By class");
			System.out.println("6)Fetch all student details By Student name.....");
			System.out.println("7)Delete Student details by roll number.....");
			System.out.println("8)Search Student details by using letter.....");
			int number = s.nextInt();
			switch (number) {
			case 1: {
				registerStudent_details();
				break;
			}

			case 2: {
				updateStudentDetailsByStdId();
				break;
			}
			case 3: {
				updateStudentDetailsByStdname();
				break;
			}
			case 4: {
				fetchAllDetails();
				break;
			}
			case 5: {
				fetchAllDetailsByclass();
				break;
			}
			case 6: {
				fetchAllDetailsByname();
				break;
			}
			case 7: {
				deleteDetailsByrollno();
				break;
			}
			case 8: {
				searchStudentByletter();
				break;
			}
			case 9: {
				System.exit(0);
				break;
			}
			default: {
				System.out.println("invalid choice......");
			}
			}

		}

	}
}
